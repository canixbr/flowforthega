# Forthega Flow — UI Components & Motion Kit v1.0

Biblioteca gerada a partir do Brand Kit e da Icon Library oficiais presentes neste trabalho.

## Entregues

- **16 cards diferentes**, em temas claro e escuro (32 SVGs).
- **10 tipos de botão**, cada um em 5 estados (50 SVGs).
- **10 notificações diferentes**, cada uma em 4 formatos (40 SVGs).
- **12 componentes auxiliares**, temas claro e escuro (24 SVGs).
- **146 SVGs editáveis** e **438 PNGs transparentes** (1x/2x/4x), quatro painéis principais e um painel dark.
- Componentes React/TypeScript com props e CSS com variáveis.
- 10 presets de movimento descritos em JSON, com durações em quadros a 30 FPS.
- Packs de SVG por cena, com referências e dados ilustrativos.

## Limites e honestidade de entrega

- Os **SVGs e PNGs são estáticos** e os presets de movimento são **somente especificações**; não foram gerados AEP, Lottie nem MP4.
- Os arquivos SVG possuem paths para todas as letras com base na tipografia Inter instalada durante a exportação. As fontes não são redistribuídas.
- Os componentes React são arquivos-fonte para integração; não foi publicado um aplicativo nem implementado backend.
- Os dados de clientes, sessões e métricas são **fictícios/ilustrativos**.
- Nenhum ícone ou logotipo foi redesenhado; foram reutilizados os assets fornecidos pelo kit anterior.

## Estrutura

01 Design System; 02 Cards; 03 Buttons; 04 Notifications; 05 UI Elements; 06 Motion; 07 Dev; 08 Previews; 09 Video Assets.

## Uso no Reel

**Formato 1080×1920 a 30 FPS**. Abra `09_VIDEO_ASSETS` para obter os SVGs de cada cena. Importe como vetor e anime os grupos identificados pelos seus IDs.
