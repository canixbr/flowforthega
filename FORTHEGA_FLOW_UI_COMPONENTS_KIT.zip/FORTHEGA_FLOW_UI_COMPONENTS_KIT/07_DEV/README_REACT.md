# Integração em React + Vite + TypeScript

Copie `components`, `types` e `styles` para `src/flow/` e importe `FlowCard`, `FlowButton`, `FlowNotification`, `FlowInput`, etc. Copie os ícones necessários de `FORTHEGA_FLOW_ICON_LIBRARY.zip` para `public/flow-icons/` e forneça URLs pelo `iconSrc`. Use `tokens.css` no escopo global, seguido de `flow.css`. O pacote não acompanha imagens simuladas do produto, backend ou acesso ao Asaas.

```tsx
import {FlowCard, FlowButton, FlowProgressBar} from './flow/components';
export function Exemplo(){return <FlowCard title="Pacote de 10 sessões" description="6 realizadas, 4 restantes" metric="60%"><FlowProgressBar value={6} max={10}/><FlowButton onClick={()=>alert('Exemplo sem integração')}>Agendar</FlowButton></FlowCard>}
```

**Atenção:** use `FlowModal` como base visual; se o fluxo exigir conformidade WCAG completa, implemente focus trap e retorno de foco (ou integre componente acessível já homologado). A biblioteca é frontend, não implementa operações de backend. O CSS utiliza variáveis do tema e respeita preferências de movimento reduzido.
