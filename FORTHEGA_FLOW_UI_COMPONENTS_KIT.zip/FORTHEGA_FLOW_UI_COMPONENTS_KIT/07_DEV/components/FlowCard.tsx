import React from 'react';
import { FlowButton } from './FlowButton';
import '../styles/flow.css';
export interface FlowCardProps { title:string; description?:string; metric?:string; iconSrc?:string; actionLabel?:string; onAction?:()=>void; children?:React.ReactNode; className?:string; }
export function FlowCard({title,description,metric,iconSrc,actionLabel,onAction,children,className=''}:FlowCardProps){
 return <section className={`flow flow-card ${className}`.trim()} aria-label={title}>
   <header className="flow-card__heading">{iconSrc&&<img className="flow-card__icon" src={iconSrc} alt="" />}{title}</header>
   {description&&<div className="flow-card__detail">{description}</div>}
   {metric&&<div className="flow-card__metric">{metric}</div>}
   {children}
   {actionLabel&&<div className="flow-card__action"><FlowButton type="button" onClick={onAction}>{actionLabel}</FlowButton></div>}
 </section>;
}
