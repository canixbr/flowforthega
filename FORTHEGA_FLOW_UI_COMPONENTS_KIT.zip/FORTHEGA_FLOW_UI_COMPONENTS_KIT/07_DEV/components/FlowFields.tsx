import React from 'react';
import '../styles/flow.css';
export function FlowInput({label,id,...props}:React.InputHTMLAttributes<HTMLInputElement> & {label:string;id:string}){return <label className="flow flow-label" htmlFor={id}><span className="flow-label__caption">{label}</span><input {...props} id={id} className="flow-input" /></label>}
export function FlowSelect({label,id,options,...props}:Omit<React.SelectHTMLAttributes<HTMLSelectElement>,'children'> & {label:string;id:string;options:{label:string;value:string}[]}){return <label className="flow flow-label" htmlFor={id}><span className="flow-label__caption">{label}</span><select {...props} id={id} className="flow-select">{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></label>}
export function FlowCheckbox({label,...props}:Omit<React.InputHTMLAttributes<HTMLInputElement>,'type'> & {label:string}){return <label className="flow flow-label"><span><input {...props} type="checkbox" /> {label}</span></label>}
export function FlowRadio({label,...props}:Omit<React.InputHTMLAttributes<HTMLInputElement>,'type'> & {label:string}){return <label className="flow flow-label"><span><input {...props} type="radio" /> {label}</span></label>}
export function FlowProgressBar({value,max=100,label}: {value:number;max?:number;label?:string}){const pct=Math.max(0,Math.min(100,max>0?100*value/max:0));return <div className="flow">{label&&<div>{label}</div>}<div className="flow-progress" role="progressbar" aria-valuemin={0} aria-valuemax={max} aria-valuenow={value}><div className="flow-progress__bar" style={{width:`${pct}%`}} /></div></div>}
export function FlowBadge({children}: {children:React.ReactNode}){return <span className="flow flow-badge">{children}</span>}
export function FlowAvatar({initial}: {initial:string}){return <span className="flow flow-avatar" aria-label={`Avatar ${initial}`}>{initial.slice(0,2)}</span>}
export function FlowDivider(){return <hr className="flow" style={{border:0,borderTop:'1px solid var(--flow-border)',margin:'16px 0'}} />}
export function FlowSkeleton({width='100%'}:{width?:string|number}){return <div className="flow-skeleton" aria-hidden="true" style={{width}} />}
export function FlowTooltip({text,children}:{text:string;children:React.ReactNode}){return <span title={text}>{children}</span>}
