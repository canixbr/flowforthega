import React from 'react';
import type { FlowButtonVariant } from '../types';
import '../styles/flow.css';
export type FlowButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: FlowButtonVariant; busy?: boolean; icon?: React.ReactNode };
export function FlowButton({variant='primary',busy=false,icon,children,className='',disabled,...props}: FlowButtonProps) {
  return <button {...props} className={`flow flow-button flow-button--${variant} ${className}`.trim()} disabled={disabled || busy} aria-busy={busy}>
    {busy ? <span aria-hidden="true">◌</span> : icon}{children}
  </button>;
}
