import React from 'react';
import type {FlowNoticeKind} from '../types';
import '../styles/flow.css';
export interface FlowNotificationProps { title?: string; message:string; kind?:FlowNoticeKind; iconSrc?:string; onDismiss?:()=>void; role?:'status'|'alert'; }
export function FlowNotification({title,message,kind='info',iconSrc,onDismiss,role}:FlowNotificationProps){
 const ariaRole=role ?? (kind==='error'?'alert':'status');
 return <div className="flow flow-notification" role={ariaRole}>
 {iconSrc&&<img width={24} height={24} src={iconSrc} alt="" />}
 <div className="flow-notification__copy">{title&&<strong>{title}</strong>}<span className="flow-notification__message">{message}</span></div>
 {onDismiss&&<button type="button" className="flow-notification__dismiss" aria-label="Fechar notificação" onClick={onDismiss}>×</button>}
 </div>;
}
