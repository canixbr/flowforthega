import React, {useEffect, useRef} from 'react';
import '../styles/flow.css';
export interface FlowModalProps { open:boolean; title:string; onClose:()=>void; children:React.ReactNode; }
export function FlowModal({open,title,onClose,children}:FlowModalProps){
 const closeRef=useRef<HTMLButtonElement>(null);
 useEffect(()=>{if(!open)return;closeRef.current?.focus();function onKey(event:KeyboardEvent){if(event.key==='Escape')onClose()}window.addEventListener('keydown',onKey);return ()=>window.removeEventListener('keydown',onKey)},[open,onClose]);
 if(!open)return null;
 return <div className="flow-modal-backdrop" onMouseDown={(e)=>{if(e.target===e.currentTarget)onClose()}}>
  <section className="flow flow-modal" role="dialog" aria-modal="true" aria-label={title}>
   <div style={{display:'flex',justifyContent:'space-between',gap:16,alignItems:'center'}}><h2>{title}</h2><button ref={closeRef} aria-label="Fechar modal" type="button" onClick={onClose}>×</button></div>{children}
  </section>
 </div>;
}
