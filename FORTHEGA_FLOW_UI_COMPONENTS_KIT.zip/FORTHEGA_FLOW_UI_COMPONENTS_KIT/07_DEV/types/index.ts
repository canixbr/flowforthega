export type FlowTheme = 'light' | 'dark';
export type FlowButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost';
export type FlowNoticeKind = 'success' | 'warning' | 'error' | 'info';
export interface FlowAppointment { id:string; customerName:string; service:string; startsAt:string; status:string; }
export interface FlowMetric { label:string; value:string; helper?:string; }
