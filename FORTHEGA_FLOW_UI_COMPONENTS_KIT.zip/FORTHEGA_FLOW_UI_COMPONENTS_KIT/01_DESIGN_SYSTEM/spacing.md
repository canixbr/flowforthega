# Grid e espaçamento

Base 8px. Espaços: 8, 12, 16, 24, 32px. Raio: 8, 12, 16, 24px. Botões: 40, 48, 56px. Área clicável recomendada 44px. Para vídeos 1080×1920/30fps, preservar área segura nas bordas.
