# Tipografia

Fonte de interface: **Inter** (Regular, Medium, SemiBold e Bold). Para PNG/SVG deste kit, os textos estão convertidos em paths e não dependem de arquivos de fonte. Os componentes React usam `font-family: Inter, system-ui, sans-serif`. Não redistribuir arquivos de fonte no ZIP.

Títulos: 20–24px, métricas: 28–40px, descrições: 14–17px, rótulos: 12–14px.
