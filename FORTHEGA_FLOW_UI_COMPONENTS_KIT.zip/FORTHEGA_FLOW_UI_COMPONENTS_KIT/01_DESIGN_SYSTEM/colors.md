# Cores aprovadas

- `#D7FF00`: verde-lima — CTA, progresso, realces, marca.
- `#1B1B1D`: grafite — texto principal, superfícies escuras.
- `#FFFFFF`: branco — superfícies claras e textos em fundos escuros.
- `#F5F5F5`: cinza claro — planos de fundo e componentes secundários.

Para as bordas e estados, usar opacidade de branco/grafite. Em exportações raster, a suavização das bordas gera tonalidades intermediárias.
