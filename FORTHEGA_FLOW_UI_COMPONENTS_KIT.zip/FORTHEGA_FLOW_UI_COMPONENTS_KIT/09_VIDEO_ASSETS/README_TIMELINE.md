# Materiais organizados por cena

Os SVGs são cópias para importação isolada em projetos de edição. As cenas 03 e 08 utilizam principalmente as gravações e o Brand Kit; a animação de revelação da logo não está renderizada. Nenhum arquivo da pasta é AEP ou uma composição de motion finalizada. **1080×1920, 30 fps, 33 segundos**. As imagens são demonstrações ilustrativas da interface, sem dados de clientes ou promessa de recursos já lançados.
