# Guia de motion — 1080 × 1920 / 30 FPS

Os 10 presets são **especificações**, não animações renderizadas. Importe as camadas de cada SVG em AE/Illustrator e use os grupos `id` documentados no `layer-map.json`. Em SVG com texto convertido a curvas, animar os grupos de texto como unidade; camadas tipográficas editáveis podem ser reconstruídas no projeto de motion.

## Presets e durações

- **CARD_POP_IN** — 12 quadros / 0.40s, easeOutBack; propriedades {"opacity": [0, 1], "scale": [0.86, 1.0]}
- **CARD_SLIDE_LEFT** — 15 quadros / 0.50s, easeOutCubic; propriedades {"x": [-90, 0], "opacity": [0, 1]}
- **CARD_SLIDE_RIGHT** — 15 quadros / 0.50s, easeOutCubic; propriedades {"x": [90, 0], "opacity": [0, 1]}
- **CARD_FLOAT** — 90 quadros / 3.00s, easeInOutSine; propriedades {"y": [0, -10, 0]}
- **CARD_SCALE_UP** — 12 quadros / 0.40s, easeOutCubic; propriedades {"scale": [0.92, 1.0], "opacity": [0, 1]}
- **NOTIFICATION_SLIDE_IN** — 9 quadros / 0.30s, easeOutCubic; propriedades {"x": [70, 0], "opacity": [0, 1]}
- **BUTTON_PRESS** — 6 quadros / 0.20s, easeInOutQuad; propriedades {"scale": [1, 0.97, 1]}
- **PROGRESS_FILL** — 20 quadros / 0.67s, easeOutCubic; propriedades {"progress": [0, 0.6]}
- **SUCCESS_REVEAL** — 10 quadros / 0.33s, easeOutCubic; propriedades {"scale": [0.8, 1.0], "opacity": [0, 1]}
- **CARD_CONNECT** — 15 quadros / 0.50s, easeInOutCubic; propriedades {"pathTrim": [0, 1]}

## Regras

Não mover mais de três cards simultaneamente; dar prioridade à narração e à leitura. Evitar loop excessivo. Para tomadas demonstrativas de funcionalidades futuras, incluir indicação discreta "Interface ilustrativa".
