# FORTHEGA FLOW — Kit de Identidade Visual

## Arquivos
- `01_LOGO_HORIZONTAL`: marca principal horizontal, com lettering em curvas e versão extra com texto editável.
- `02_SIMBOLO`: símbolo `F` isolado em SVG e PNG transparente.
- `03_LOGO_WHITE`: símbolo verde-lima, texto branco; ideal em fundo grafite.
- `04_LOGO_DARK`: símbolo verde-lima, texto grafite; ideal em fundo branco.
- `05_APP_ICON`: símbolo grafite sobre fundo verde-lima arredondado.
- `06_FAVICON`: favicon SVG, ICO e PNGs, mais ícone Apple Touch.
- `07_MONOCROMATICO`: logos e símbolos totalmente pretos ou brancos.
- `PREVIEW_GERAL.png`: apresentação de todas as versões.
- `FLOW_DESIGN_TOKENS.json`: paleta e metadados para desenvolvedores.

## Paleta
| Uso | Cor |
|---|---|
| Destaque | `#D7FF00` |
| Grafite | `#1B1B1D` |
| Branco | `#FFFFFF` |

## Tipografia
O logotipo SVG oficial tem todos os caracteres convertidos em **caminhos vetoriais**, sem dependência de fonte instalada. 
A fonte da composição foi **Inter Regular** (`FORTHEGA`) e **Inter Black Italic** (`FLOW`).
A versão `FLOW_LOGO_TEXTO_EDITAVEL.svg` contém elementos `<text>` para edição de letras no Inkscape/Illustrator, exigindo Inter instalado localmente para consistência. Nenhum arquivo de fonte acompanha este pacote.

## Vetorização / fidelidade
O símbolo foi **reconstruído manualmente em duas formas Bézier SVG**, tomando como referência a ilustração gerada na conversa. Não há raster embutido nos SVGs.
A referência original tinha leve brilho e não definia curvas vetoriais exatas; por isso, esta versão é uma **reconstrução fiel aproximada**, não uma cópia matemática perfeita do original. As cores foram normalizadas para os HEX solicitados, e o brilho foi removido conforme a direção flat.

## Uso
- SVG: website, sidebar do aplicativo, motion graphics e impressão.
- PNG transparente: vídeo, editores gráficos e apresentações.
- `FLOW_APP_ICON`: aplicativo / PWA.
- `FLOW_FAVICON`: favicon e marcadores do browser.
- Para fundeado escuro: `FLOW_LOGO_WHITE`; para fundo claro: `FLOW_LOGO_DARK`.
- Preserve margem livre ao redor do símbolo; não distorça, aplique gradientes nem sombras.
- Teste o favicon na interface real; em 16 px, o detalhe entre as duas curvas é naturalmente reduzido.

## Aviso
O kit é uma entrega gráfica. Não assegura exclusividade jurídica do símbolo ou do nome, nem valida disponibilidade de marca no INPI.
