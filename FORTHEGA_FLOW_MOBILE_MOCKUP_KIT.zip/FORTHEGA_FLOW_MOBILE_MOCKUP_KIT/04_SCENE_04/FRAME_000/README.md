Frame 000: dispositivo propositalmente invisível (opacidade 0). A entrada começa nos frames seguintes.
