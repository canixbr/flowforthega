A tela EMPTY é transparente e aceita tela SVG/PNG de 390 × 844 pixels, recortada pelo raio de 34px.
