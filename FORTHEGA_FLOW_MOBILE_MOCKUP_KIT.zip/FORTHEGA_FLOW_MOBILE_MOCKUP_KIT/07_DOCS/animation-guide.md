# Forthega Flow — Animação da cena 04

Formato: **1080 × 1920, 30 fps, 90 frames (0–89), 3 segundos**.

| Frames | Ação |
|---|---|
| 000–012 | Celular surge com escala 85→100%, opacidade 0→100%. |
| 013–027 | Rotação 2.5D -12° no eixo Y. |
| 028–050 | Dashboard no celular, flutuação discreta. |
| 051–065 | Crossfade real Dashboard → Agenda, retorno próximo de frontal. |
| 066–089 | Aproximação 105→125%, prepara cena 05. |

Usar `05_EDITABLE_PROJECT/mockup.html` para reproduzir as 90 posições; ajuste `mockup.js` e `mockup.css` para editar keyframes. Teclas espaço: play/pause; setas: ±1 frame; Home: início. **Presets LEFT e RIGHT usam transformações CSS com perspective (2.5D); não há geometria Blender e nem rotação 3D física.**

Os arquivos `01_PHONE_GEOMETRY` contêm camadas SVG vetoriais, `02_SCREEN_PRESETS` guarda interfaces e composições, `03_MOTION_PRESETS` contém presets derivados e `04_SCENE_04` frames-chave. Sem motion blur embutido; habilite na montagem.

IMPORTANTE: Dados de telas são fictícios; os SVGs de dashboard e agenda foram reutilizados do kit anterior, sem redesenho nem conexão a Supabase/Asaas.
