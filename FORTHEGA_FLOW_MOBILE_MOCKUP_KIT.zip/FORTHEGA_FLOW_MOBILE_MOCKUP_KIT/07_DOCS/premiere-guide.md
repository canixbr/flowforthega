# Guia Premiere Pro — Flow

1. Crie sequência vertical **1080x1920, 30 fps**.
2. Importe PNGs de `06_EXPORTS/PNG_1080` para montagem estática; para animar camadas, importe os PNGs das partes separadas ou renderize os SVGs da pasta `01_PHONE_GEOMETRY`.
3. Ordem de empilhamento, de baixo para cima: sombra (V1), body/side (V2), screen (V3), bezel/speaker/buttons (V4), highlights (V5), overlays (V6). Nossas exportações são transparentes fora do smartphone.
4. Ajuste as proporções mantendo a tela **390:844**. Evite esticar imagens para preencher o aparelho.
5. Troca de tela: use as composições DASHBOARD e AGENDA e transição breve entre frames 51–65 (clipe de 3s, inicia no Reel global 00:09).
6. Use os frames-chaves de `07_DOCS/motion-specs.json`. Ajuste a posição/escala com keyframes; uma rotação 3D real é mais indicada no After Effects.
7. Se precisar de movimento 2.5D com tela independente, capture `05_EDITABLE_PROJECT/mockup.html` e faça a composição no After Effects; isso conserva o encaixe da tela.
8. Configure desfoque de movimento apenas no projeto de edição. Não aplique blur aos arquivos SVG originais.

Não confunda as prévias com vídeo de produto em produção.
