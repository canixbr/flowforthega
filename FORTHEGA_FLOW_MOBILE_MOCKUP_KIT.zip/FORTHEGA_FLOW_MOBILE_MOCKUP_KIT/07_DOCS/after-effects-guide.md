# Guia After Effects — Flow

- Composição: 1080 × 1920, 30 fps, duração **00:00:03:00**.
- Importe `PHONE_BACK`, `PHONE_SIDE`, `PHONE_BODY`, `PHONE_BEZEL`, `PHONE_SPEAKER`, `PHONE_BUTTONS`, `PHONE_HIGHLIGHT` como camadas vetoriais, convertendo para Shapes se necessário.
- Crie a pré-composição `PHONE_SCREEN_CONTENT`, 390 × 844 px, e substitua sua mídia por Dashboard, Agenda, detalhes ou uma nova tela.
- Máscara da tela: retângulo 390 × 844 com raio proporcional a 34px, posicionado internamente x=26/y=53 no aparelho 442 × 950.
- Aplique parent das camadas do celular a um nulo `FLOW_PHONE_CTRL` (2.5D), gire eixo Y ~12° e mantenha a tela como filha, para evitar desalinhamento.
- Coloque `PHONE_BEZEL` acima da pré-composição de tela, nunca uma camada opaca sobre a área útil.
- Use os timings do `motion-specs.json`. Crossfade Dashboard/Agenda entre frames 51–65; movimento de aproximação até o frame 89.
- Ative motion blur para camadas em movimento. É uma simulação 2.5D; para parallax físico real, reconstrua geometria 3D.
- Os SVGs são vetoriais, sem bitmap embutido, e os PNGs auxiliares possuem alpha real.

O kit não inclui um `.aep` nativo.
