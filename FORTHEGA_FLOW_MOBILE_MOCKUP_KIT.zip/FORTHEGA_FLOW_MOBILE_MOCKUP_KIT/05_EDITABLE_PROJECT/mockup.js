/* Forthega Flow — reusable 2.5D HTML mockup, no external packages */
'use strict';
const $=id=>document.getElementById(id);
const params=new URLSearchParams(location.search);
const capture=params.get('capture')==='1';
const stage=$('stage'), viewport=$('stageViewport'), phone=$('phone');
const screens={dashboard:$('screenDashboard'),agenda:$('screenAgenda'),agendamento:$('screenDetails'),custom:$('screenCustom')};
const state={frame:0,playing:false,preset:'SCENE_04',screen:'dashboard',lastStamp:0,accum:0,customUrl:null};
const easeOut=t=>1-Math.pow(1-t,3);
const easeInOut=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const seg=(f,a,b)=>clamp((f-a)/(b-a));
const lerp=(a,b,t)=>a+(b-a)*t;
function fitStage(){
 if(capture){stage.style.transform='none';stage.style.left='0px';stage.style.top='0px';return;}
 const w=viewport.clientWidth, h=viewport.clientHeight;
 const scale=Math.min((w-36)/1080,(h-30)/1920);
 stage.style.transform=`scale(${scale})`;
 stage.style.left=`${(w-1080*scale)/2}px`;
 stage.style.top=`${(h-1920*scale)/2}px`;
}
function setScreen(name){
 if(name==='empty'){Object.values(screens).forEach(e=>{e.style.display='none';e.style.opacity='0'});state.screen='empty';}
 else {state.screen=name;Object.entries(screens).forEach(([key,e])=>{e.style.display=key===name?'block':'none';e.style.opacity=key===name?'1':'0'});}
 document.querySelectorAll('[data-screen]').forEach(b=>b.classList.toggle('active',b.dataset.screen===name));
}
function scenePose(f){
 const p1=easeOut(seg(f,0,12)),p2=easeInOut(seg(f,13,27)),p3=easeInOut(seg(f,51,65)),p4=easeInOut(seg(f,66,89));
 let scale=lerp(.85,1,p1); if(f>50)scale=lerp(1,1.05,p3);if(f>65)scale=lerp(1.05,1.25,p4);
 let y=lerp(90,0,p1);if(f>=28 && f<=50)y=-9*Math.sin(Math.PI*(f-28)/22);if(f>65)y=lerp(0,-35,p4);
 let ry=0;if(f>=13)ry=lerp(0,-12,p2);if(f>50)ry=lerp(-12,-2,p3);if(f>65)ry=lerp(-2,0,p4);
 return {scale,ry,y,opacity:f<13?p1:1,agendaOpacity:f<51?0:f<=65?p3:1};
}
const presetPose={FRONT:{scale:1.0,ry:0,y:0},LEFT:{scale:1,ry:-17,y:0},RIGHT:{scale:1,ry:17,y:0},CLOSEUP:{scale:1.38,ry:-7,y:-70},FLOATING:{scale:1,ry:-8,y:-18},SCREEN_FOCUS:{scale:1.36,ry:0,y:-90}};
function updateFrame(frame){
 state.frame=Math.max(0,Math.min(89,Math.round(frame)));
 const f=state.frame;
 let p=state.preset==='SCENE_04'?scenePose(f):presetPose[state.preset]||presetPose.FRONT;
 phone.style.transform=`translateY(${p.y}px) perspective(1350px) rotateY(${p.ry}deg) scale(${p.scale*1.47})`;
 phone.style.opacity=p.opacity??1;
 const ag=state.preset==='SCENE_04'?p.agendaOpacity:undefined;
 if(state.preset==='SCENE_04' && state.screen!=='custom' && state.screen!=='empty'){
  screens.dashboard.style.display='block';screens.agenda.style.display='block';screens.agendamento.style.display='none';screens.custom.style.display='none';
  screens.dashboard.style.opacity=String(1-ag);screens.agenda.style.opacity=String(ag);
 } else if (state.screen!=='empty'){
  Object.entries(screens).forEach(([key,e])=>{e.style.display=key===state.screen?'block':'none';e.style.opacity=key===state.screen?'1':'0'});
 }
 if($('timeline'))$('timeline').value=f;
 if($('frameLabel'))$('frameLabel').textContent=`FRAME ${String(f).padStart(3,'0')} / 089`;
 if($('timeLabel'))$('timeLabel').textContent=`00:${(f/30).toFixed(3).padStart(6,'0')}`;
 if($('phase'))$('phase').textContent=f<=12?'Entrada do mockup':f<=27?'Rotação lateral':f<=50?'Dashboard em destaque':f<=65?'Dashboard → Agenda':'Aproximação final';
}
function play(t){if(!state.playing)return;if(!state.lastStamp)state.lastStamp=t;state.accum+=(t-state.lastStamp);state.lastStamp=t;
 while(state.accum>=1000/30){state.accum-=1000/30; if(state.frame>=89){pause();return;}updateFrame(state.frame+1)}requestAnimationFrame(play);
}
function pause(){state.playing=false;state.lastStamp=0;const b=$('playPause');if(b)b.textContent='▶ Reproduzir'}
function start(){if(state.playing){pause();return;}if(state.frame===89)updateFrame(0);state.playing=true;state.accum=0;state.lastStamp=0;$('playPause').textContent='Ⅱ Pausar';requestAnimationFrame(play)}
if(capture){document.body.classList.add('capture');const p=params.get('preset')||'SCENE_04';state.preset=p;const s=params.get('screen');if(s)setScreen(s);if(params.get('transparent')==='1')stage.classList.add('transparent-bg');} else {
 document.querySelectorAll('[data-screen]').forEach(b=>b.addEventListener('click',()=>{state.preset='FRONT';document.querySelectorAll('[data-preset]').forEach(p=>p.classList.toggle('active',p.dataset.preset==='FRONT'));setScreen(b.dataset.screen);updateFrame(state.frame)}));
 document.querySelectorAll('[data-preset]').forEach(b=>b.addEventListener('click',()=>{pause();state.preset=b.dataset.preset;document.querySelectorAll('[data-preset]').forEach(p=>p.classList.toggle('active',p===b));updateFrame(state.frame)}));
 $('timeline').addEventListener('input',e=>{pause();updateFrame(+e.target.value)});$('playPause').addEventListener('click',start);
 $('reset').addEventListener('click',()=>{pause();state.preset='SCENE_04';document.querySelectorAll('[data-preset]').forEach(b=>b.classList.toggle('active',b.dataset.preset==='SCENE_04'));updateFrame(0)});
 $('prevFrame').addEventListener('click',()=>{pause();updateFrame(state.frame-1)});$('nextFrame').addEventListener('click',()=>{pause();updateFrame(state.frame+1)});
 $('transparentToggle').addEventListener('change',e=>stage.classList.toggle('transparent-bg',e.target.checked));
 $('guidesToggle').addEventListener('change',e=>$('stageGuide').classList.toggle('visible',e.target.checked));
 $('customScreen').addEventListener('change',e=>{const file=e.target.files?.[0];if(!file)return;if(state.customUrl)URL.revokeObjectURL(state.customUrl);state.customUrl=URL.createObjectURL(file); screens.custom.src=state.customUrl;state.preset='FRONT';document.querySelectorAll('[data-preset]').forEach(p=>p.classList.toggle('active',p.dataset.preset==='FRONT'));setScreen('custom');updateFrame(state.frame)});
 document.addEventListener('keydown',e=>{if(e.target?.tagName==='INPUT')return;if(e.code==='Space'){e.preventDefault();start()}if(e.code==='ArrowRight'){e.preventDefault();pause();updateFrame(state.frame+1)}if(e.code==='ArrowLeft'){e.preventDefault();pause();updateFrame(state.frame-1)}if(e.code==='Home'){e.preventDefault();pause();updateFrame(0)}});
}
window.addEventListener('resize',fitStage);fitStage();updateFrame(capture?Number(params.get('frame')||50):0);
