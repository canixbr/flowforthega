# FORTHEGA FLOW — MOBILE MOCKUP & MOTION KIT V1.0

**Mockup vetorial genérico e editável**, com tela substituível 390 × 844. Montado reaproveitando fielmente as telas vetoriais do `FORTHEGA_FLOW_DASHBOARD_AGENDA_KIT.zip` e a identidade do Brand Kit. Não há foto nem screenshot de produto em produção.

## Abrir o editor offline

Extraia o ZIP e abra **`05_EDITABLE_PROJECT/mockup.html`** no navegador. A página foi preparada para funcionar localmente (HTML/CSS/JS sem dependências externas). Na área esquerda, alterne telas, 6 presets de ângulo, carregue uma tela PNG/SVG e use a linha do tempo da **cena 04 (90 quadros, 30fps, 3s)**. Use Espaço para reproduzir/pausar e setas para avançar quadro a quadro.

## Onde estão os arquivos

| Diretório | Material |
|---|---|
| `01_PHONE_GEOMETRY/` | Camadas vetoriais: body, back, side, bezel transparente, máscara, speaker, buttons, highlights, shadow |
| `02_SCREEN_PRESETS/` | Dashboard, Agenda, Detalhes e EMPTY; originais SVG+PNG, composições vetoriais autônomas |
| `03_MOTION_PRESETS/` | 6 enquadramentos derivados do mesmo dispositivo |
| `04_SCENE_04/` | Frames-chave 000, 027, 050, 065 e 089 (pasta FRAME_090 representa limite final) |
| `05_EDITABLE_PROJECT/` | Editor HTML/CSS/JS e SVG/PNG locais — sem backend |
| `06_EXPORTS/SVG/` | SVGs vetoriais 442 × 950 e composições 1080 × 1920 |
| `06_EXPORTS/PNG_1080/` | PNGs com transparência e 1080 × 1920 |
| `06_EXPORTS/PNG_2160/` | PNGs com transparência e 2160 × 3840 |
| `07_DOCS/` | Dimensões, camadas, motion specs e guias para Premiere e After Effects |
| `08_PREVIEWS/` | Presets e storyboard; MP4 demonstrativo se renderizado |

## Camadas / visibilidade

1. Shadow **abaixo** do corpo, quando usada.
2. Back, side e body.
3. Tela dashboard/agenda/detalhes ou imagem personalizada; máscara de cantos em x=26/y=53 e 390 × 844 px.
4. Bezel transparente — com buraco real na área da tela.
5. Speaker e botões.
6. Highlight sobre tudo (efeito leve).

**A tela é totalmente substituível** e não está incorporada ao corpo do smartphone. Os SVGs de composição incluem paths reais das telas do kit anterior — não imagens raster embutidas nem referências de arquivo externas.

## Regras / limitações reais

- **Interface ilustrativa**, com dados fictícios; não representa produto já operando em produção.
- Os ângulos são transformações **2.5D/perspectiva**, não 3D físico, e não há `.blend` ou `.aep`.
- A composição HTML/CSS/JS possui animação funcional por frame. Os 10 presets estão especificados no `motion-specs.json`; alguns são variantes conceituais não renderizadas como vídeos independentes.
- O vídeo MP4 é uma **prévia demonstrativa** sobre fundo grafite, não um render transparente; os PNGs e SVGs mantêm alpha.
- A validação direta no navegador Chromium deste ambiente foi bloqueada por política de acesso (tanto file:// quanto localhost). Foram verificados os recursos estáticos, HTML/JS por verificações locais e renders SVG; testar a interatividade no seu navegador após extrair.
- O arquivo-fonte é HTML/CSS/JS editável, não AEP ou Blender.

## Referências

- Paleta: `#D7FF00`, `#1B1B1D`, `#FFFFFF`, `#F5F5F5`.
- Tela sem deformação: proporção **390:844**.
- Composição final: **1080x1920** a **30fps**.
- Motion blur a aplicar no projeto de edição, nunca em arte-fonte.
