# FORTHEGA FLOW — Biblioteca Vetorial de Ícones

Referência de identidade: FORTHEGA_FLOW_BRAND_KIT.zip (kit presente na conversa).

**Conteúdo:** 70 desenhos distintos, 4 variações por desenho = 280 SVGs e 560 PNGs (512 e 1024 px).
Cada desenho foi construído geometricamente em grade 24×24, com linhas base de 1,75 unidades e tampas/cantos arredondados.

## Paleta
- LIME: `#D7FF00`
- DARK: `#1B1B1D`
- WHITE: `#FFFFFF`
- LIGHT: `#F5F5F5` (usado apenas como fundo de prévias)

## Variações
- LIME: contorno em verde-lima sobre fundo transparente.
- DARK: contorno grafite sobre fundo transparente.
- WHITE: contorno branco sobre fundo transparente.
- FILLED: tratamento de silhueta usando preenchimento nas formas fechadas e reforço de traços nas abertas; verde-lima sobre transparência. Elementos internos podem ter recortes grafite para legibilidade. **Não há placa retangular atrás dos ícones.**

**Nota técnica:** Para signos compostos apenas por hastes (setas, +, menu), a variante FILLED tem traço mais encorpado em vez de preencher uma região inexistente. Isso mantém a geometria reconhecível, sem inserir fundos decorativos.

## Produção e motion
Cada SVG inclui um grupo semântico do ícone e elementos `part-XX-role`; as partes podem ser usadas para keyframes separadas, strokes e transformações.
Os SVGs são vetores reais (`path`, `rect`, `circle`, etc), sem dependência de fonte ou raster embutido.
PNG é rasterização direta do SVG. Todas as artes exportadas preservam alpha.
Para vídeo, recomenda-se LIME sobre grafite e DARK sobre branco. WHITE sobre fundo escuro também funciona.

## Diretórios
As 7 primeiras pastas organizam ícones por contexto; `08_PREVIEWS` contém quatro grades para revisão; `09_DEV` contém registry TypeScript, CSS, manifest e instruções React.

## Direitos e observações
- Ícones são desenhos geométricos próprios desta biblioteca, não cópias intencionais de marcas de terceiros.
- `ICON_PIX` é um pictograma genérico de pagamento instantâneo, não a identidade institucional do Pix.
- A biblioteca não substitui a conferência de acessibilidade, contraste e legibilidade no tamanho final em cada material.
