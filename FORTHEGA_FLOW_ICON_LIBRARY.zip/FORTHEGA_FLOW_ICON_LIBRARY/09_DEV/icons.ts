/** FORTHEGA FLOW — Icon Registry | React/Vite/TypeScript */
/** Copy 01–07 category folders alongside this file, or import them as public static files. */

export const flowIconNames = [
  'ICON_TERAPIAS',
  'ICON_MASSOTERAPIA',
  'ICON_BEM_ESTAR',
  'ICON_BARBEARIA',
  'ICON_ESTETICA',
  'ICON_SALAO',
  'ICON_CLINICA',
  'ICON_AUTONOMO',
  'ICON_CALENDARIO',
  'ICON_AGENDAMENTO_CONFIRMADO',
  'ICON_AGENDAMENTO_PENDENTE',
  'ICON_REAGENDAR',
  'ICON_CANCELAR_AGENDAMENTO',
  'ICON_RELOGIO',
  'ICON_HORARIOS',
  'ICON_LEMBRETE',
  'ICON_NOTIFICACAO',
  'ICON_CHECK_CONFIRMACAO',
  'ICON_CLIENTES',
  'ICON_CLIENTE_INDIVIDUAL',
  'ICON_NOVO_CLIENTE',
  'ICON_HISTORICO',
  'ICON_ATENDIMENTO',
  'ICON_PACOTE_SESSOES',
  'ICON_PROGRESSO_SESSOES',
  'ICON_AVALIACAO_CLIENTE',
  'ICON_FINANCEIRO',
  'ICON_CARTEIRA',
  'ICON_PAGAMENTO',
  'ICON_PIX',
  'ICON_CARTAO',
  'ICON_RECEBIMENTOS',
  'ICON_DESPESAS',
  'ICON_FATURAMENTO',
  'ICON_GRAFICO_CRESCIMENTO',
  'ICON_RELATORIOS',
  'ICON_COMISSOES',
  'ICON_REPASSES',
  'ICON_MARKETING',
  'ICON_AUTOMACAO',
  'ICON_REATIVACAO',
  'ICON_MENSAGEM',
  'ICON_COMENTARIO',
  'ICON_CAMPANHA',
  'ICON_ANIVERSARIO',
  'ICON_LINK',
  'ICON_FORMULARIO',
  'ICON_PESQUISA',
  'ICON_EQUIPE',
  'ICON_COLABORADOR',
  'ICON_ESTABELECIMENTO',
  'ICON_ESTOQUE',
  'ICON_INSUMOS',
  'ICON_CADEIRA_ALUGUEL',
  'ICON_METAS',
  'ICON_CONFIGURACOES',
  'ICON_SETA_DIREITA',
  'ICON_SETA_BAIXO',
  'ICON_SETA_CIMA',
  'ICON_PLAY',
  'ICON_PAUSE',
  'ICON_PLUS',
  'ICON_CLOSE',
  'ICON_SEARCH',
  'ICON_MENU',
  'ICON_FILTER',
  'ICON_SUCCESS',
  'ICON_WARNING',
  'ICON_LOADING',
  'ICON_CONNECTION',
] as const;
export type FlowIconName = (typeof flowIconNames)[number];
export type FlowIconVariant = 'LIME' | 'DARK' | 'WHITE' | 'FILLED';

/** Vite glob imports all SVGs as URL assets. Keep relative directory structure. */
const svgUrls = import.meta.glob('../0[1-7]_*/ICON_*_*.svg', {
  eager: true,
  query: '?url',
  import: 'default',
}) as Record<string, string>;

export function getFlowIconUrl(name: FlowIconName, variant: FlowIconVariant = 'DARK'): string {
  const entry = Object.entries(svgUrls).find(([path]) => path.endsWith(`/${name}_${variant}.svg`));
  if (!entry) throw new Error(`Forthega Flow icon not found: ${name}_${variant}`);
  return entry[1];
}

/** Example: <img src={getFlowIconUrl('ICON_CALENDARIO', 'LIME')} alt="Agenda" /> */
