# Integração dos ícones Forthega Flow no React + Vite + TypeScript

## Estrutura
Mantenha as sete pastas `01_SEGMENTOS` a `07_INTERFACE_MOTION` na mesma pasta-pai de `09_DEV`, ou ajuste a rota de importação em `icons.ts`.

## Uso
```tsx
import { getFlowIconUrl } from './icons';
const url = getFlowIconUrl('ICON_CALENDARIO', 'LIME');
<img src={url} alt="Agenda" width={24} height={24} />
```

O glob com `?url` retorna caminhos de assets gerenciados pelo Vite. O projeto precisa incluir as pastas com os SVGs para resolver os imports.
Para manipular `part-*` individualmente em motion graphics, importe o SVG no editor ou inline o arquivo de forma sanitizada.
SVGs fornecem sua própria cor e traços; imagens `<img>` não herdam `currentColor`.

## Licenciamento
Ícones originais desenhados para este pacote; não contém logomarcas oficiais de terceiros.
Não confundir o símbolo `ICON_PIX` genérico com o logotipo oficial do Pix.
