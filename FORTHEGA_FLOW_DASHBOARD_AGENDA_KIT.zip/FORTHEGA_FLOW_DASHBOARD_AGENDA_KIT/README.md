# FORTHEGA FLOW — DASHBOARD & AGENDA VISUAL KIT V1.0

**Arte vetorial editável + demonstração local.** Os dados são fictícios e não representam o software pronto para produção.

## Origem dos recursos
- `FORTHEGA_FLOW_BRAND_KIT.zip`: SVGs do logotipo/símbolo, reutilizados sem alteração.
- `FORTHEGA_FLOW_ICON_LIBRARY.zip`: ícones vetoriais oficiais, embedados nos SVGs e copiados para React.
- `FORTHEGA_FLOW_UI_COMPONENTS_KIT.zip`: tokens, `FlowButton`, `FlowCard` e componentes originais preservados; alguns cards também são entregues nesta pasta como arquivos reutilizáveis.

## Telas
- Dashboard desktop 1440×900 e mobile 390×844.
- Agenda desktop 1440×900 e mobile 390×844.
- Tela de detalhes de agendamento 390×844.
- Cards flutuantes: Agenda, Clientes, Pacotes e Financeiro.
- Mockup 2D de celular com tela vazada/transparente e telas separadas.

## Formatos
- Cada recurso principal possui `.svg` com texto vetorizado, `.editable.svg` com textos editáveis e PNG 1× e 2×. Telas mobile/cards possuem também PNG 4×.
- SVGs usam path, rect, círculos e grupos de curvas editáveis; não contêm fotos ou Base64.
- `07_VIDEO_ASSETS` reúne os recursos organizados por cena.
- `08_PREVIEWS` contém imagens JPG/PNG para leitura rápida.

## Animações
`05_MOTION/motion-specs.json` possui **10 especificações**, NÃO vídeos ou arquivos `.aep`/Lottie. A rotação 3D deve ser realizada no editor de vídeo.

## React
`06_REACT_DEMO` contém demo React/TypeScript local com navegação e controles básicos de demonstração. Não há integração Supabase ou Asaas.

## Uso no vídeo
Cenas 04 (9–12s), 05 (12–15s), 06 (15–19s), a 30 FPS, 1080×1920.

**Cuidado**: elementos desktop foram feitos para demonstração; a interface final deverá ser validada na aplicação funcional.

## Validação do projeto React

Sintaxe TS/TSX e resolução de imports locais verificadas. O build final (`npm run build`) **não foi executado neste ambiente**, pois o registro npm não está acessível e as dependências não estão instaladas. Execute no seu computador para homologar.

## Visualização sem instalação

Abra `VISUALIZAR_OFFLINE.html` no navegador dentro desta pasta extraída. Permite alternar visualizações e inspecionar as cenas sem npm.

Materiais adicionais: `FLOW_SCREEN_TRANSITION.svg` é máscara estática para edição; `FLOW_DASHBOARD_INTEGRATION.svg` reúne os quatro módulos com grupos separados.
