# Forthega Flow — Demonstração visual (React / Vite / TypeScript)

Projeto ilustrativo, com dados fictícios. **Sem Supabase, Asaas, login, pagamentos ou funcionalidades de produção.**

## Execução
```bash
npm install
npm run dev
```

## Testes
```bash
npm run build
```

Reutiliza diretamente o `FlowButton`, `FlowCard` e o CSS original do UI Components Kit, além de SVGs oficiais da biblioteca de ícones e logotipo. A agenda demonstra filtro, troca de data, visualização semanal e modal local, sem persistir dados.
