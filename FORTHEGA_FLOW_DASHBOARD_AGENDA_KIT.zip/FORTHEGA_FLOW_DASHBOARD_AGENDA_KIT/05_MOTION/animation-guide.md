# Guia de animação — Forthega Flow

Formato: **1080 × 1920**, **30 FPS**.

- Cena 04 (09–12s): celular entra com escala 0,88–1, rotação leve, troca Dashboard → Agenda por máscaras ou edição de posição; preservar tela e moldura como camadas independentes.
- Cena 05 (12–15s): Agenda da esquerda; Clientes da direita; linha verde-lima desenhada com máscara.
- Cena 06 (15–19s): pacotes e financeiro entram; barra 0–60%; convergência dos quatro módulos.
- Não sobrepor informações na área do rosto do apresentador; reposicionar cards na composição final.
- Motion specs são descrições de movimento, não animações renderizadas.
- O mockup de celular é vetorial 2D com camadas separadas; rotação 3D real requer aplicação dos movimentos em editor de vídeo.
- Fontes não são incluídas; a identidade segue Inter e os SVGs finais têm letras vetorizadas. As cópias .editable.svg preservam texto.
